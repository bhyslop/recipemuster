# JJK Kit Source

Edits here apply to the kit source only. Do not modify the active installation in `.claude/` or the parent project's CLAUDE.md.
